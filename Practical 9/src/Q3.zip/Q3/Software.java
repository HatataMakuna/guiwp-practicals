package Q3;
public class Software {
    private String name;

    public Software() {
    }

    public Software(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
